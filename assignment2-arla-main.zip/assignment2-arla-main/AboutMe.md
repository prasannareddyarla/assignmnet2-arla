# Prasanna Arla
> I have completed my engineering in Hyderabad in the year of 2019 and worked in cognizant technologies for one year as technology support. 
![prasanna arla](/image.jpg)
 
